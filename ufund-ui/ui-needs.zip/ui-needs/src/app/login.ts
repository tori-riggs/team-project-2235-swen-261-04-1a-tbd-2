export interface AuthCredentials {
    username: string;
    password: string;
    authLevel: string;
}