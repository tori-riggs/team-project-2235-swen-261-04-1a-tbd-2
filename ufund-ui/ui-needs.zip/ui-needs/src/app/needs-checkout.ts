export interface NeedCheckout {
    username: string;
    checkoutIds: number [];
}