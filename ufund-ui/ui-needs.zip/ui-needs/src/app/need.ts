export interface Need {
    id: number;
    name: string;
    cost: number;
    quantity: number;
    description: string;
}